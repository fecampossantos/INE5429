certbot.compat.misc module
==========================

.. automodule:: certbot.compat.misc
    :members:
    :undoc-members:
    :show-inheritance:
