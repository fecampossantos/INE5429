"""Certbot compatibility test configurators"""
